package Assignments;

public class MyProfile {
    public static void main(String[] args) {
        System.out.println("Robert Daniels Jr\r\n" + //
                "Year Up : Pittsburgh\r\n" + //
                "Career Goal : Full Stack Engineer\r\n" + //
                "Age : 22 years old\r\n" + //
                "An accomplished student with a passion for learning and furthering my knowledge regarding technology. Areas of interest are Web Development, information system analysis/design, and expertise in many coding languages." + //
                "I enjoy learning about software engineering and any concepts that encompass this field. I have recently been studying manipulating data structures, front-end development, and connecting relational databases. \r\n" + //
                "\r\n" + //
                "");
    }
}
